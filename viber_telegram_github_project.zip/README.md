# Viber → Telegram visual experiment (GitHub Actions)

This is a **best-effort experiment**, not a Telegram client. It attempts to change the Android app label, launcher icon and package ID while retaining Viber's code.

## Files
- `assets/telegram_icon.png` — the icon you selected.
- `build.py` — decodes every APK split, updates the manifest/icon resources, rebuilds and signs all splits.
- `.github/workflows/build.yml` — runs the build in GitHub Actions.

## Important limitations
- Changing the package ID/signature can break Viber login, push notifications, deep links, in-app updates, or server-side checks.
- This does **not** replace Viber's internal chat UI with Telegram's UI. That requires extensive app-specific reverse engineering and may not be feasible.
- The output is an `.apks` split package, not a single `.apk`. Install it with a split-APK installer such as SAI. Keep the original Viber installed.
- This script is an initial prototype. APKTool may fail on particular protected/obfuscated split resources; if it does, inspect the Actions log and adjust the script.
- Use only for your own testing and do not distribute it as the real Telegram app.

## Setup
1. Create a GitHub repository and upload these project files.
2. Upload your original `Viber_29.5.0.0.apks` as an asset in a **private GitHub Release**. Do not commit the 130 MB file into the repository.
3. Copy the direct asset download URL.
4. Open **Actions → Build Viber Telegram experiment → Run workflow**.
5. Paste the asset URL into `apks_download_url` and run it.
6. When finished, open the workflow run, download the `Telegram-Viber-experiment` artifact, and install the `.apks` file with SAI.

The workflow creates a temporary signing key on each run. Because the key changes every run, uninstall the previous experimental build before installing a newly built one.

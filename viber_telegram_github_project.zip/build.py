#!/usr/bin/env python3
import os, sys, zipfile, shutil, subprocess, pathlib, xml.etree.ElementTree as ET

ROOT = pathlib.Path.cwd()
WORK = ROOT / "work"
INPUT = ROOT / "input.apks"
OUT = ROOT / "output"
APKTOOL = os.environ.get("APKTOOL", "apktool")
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"
NEW_PACKAGE = os.environ.get("NEW_PACKAGE", "com.viber.voip.telegramexperiment")
LABEL = os.environ.get("APP_LABEL", "Telegram")
ICON = ROOT / "assets" / "telegram_icon.png"

def run(*args):
    print("+", " ".join(map(str,args)), flush=True)
    subprocess.run(list(map(str,args)), check=True)

def main():
    if not INPUT.exists():
        raise SystemExit("Missing input.apks. Download the original Viber .apks file into the repository workspace.")
    if not ICON.exists():
        raise SystemExit("Missing assets/telegram_icon.png")
    shutil.rmtree(WORK, ignore_errors=True)
    shutil.rmtree(OUT, ignore_errors=True)
    WORK.mkdir()
    OUT.mkdir()
    with zipfile.ZipFile(INPUT) as z:
        z.extractall(WORK / "original")
    apks = sorted((WORK/"original").glob("*.apk"))
    if not apks:
        raise SystemExit("No APK splits found in input.apks")

    rebuilt=[]
    for n, apk in enumerate(apks):
        decoded = WORK / f"decoded_{n}"
        run(APKTOOL, "d", "-f", str(apk), "-o", str(decoded))
        manifest = decoded / "AndroidManifest.xml"
        tree = ET.parse(manifest)
        root = tree.getroot()
        root.set("package", NEW_PACKAGE)
        app = root.find("application")
        if app is not None:
            if apk.name == "base.apk":
                app.set(ANDROID_NS+"label", LABEL)
                app.set(ANDROID_NS+"icon", "@mipmap/ic_launcher")
            # Authorities must be unique after changing the package id.
            for node in root.iter():
                auth = node.get(ANDROID_NS+"authorities")
                if auth:
                    node.set(ANDROID_NS+"authorities", auth.replace("com.viber.voip", NEW_PACKAGE))
        tree.write(manifest, encoding="utf-8", xml_declaration=True)

        if apk.name == "base.apk":
            # Add a launcher icon at every common density. Android will select the best match.
            for density in ("mdpi","hdpi","xhdpi","xxhdpi","xxxhdpi"):
                folder = decoded / "res" / f"mipmap-{density}"
                folder.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ICON, folder / "ic_launcher.png")
            # Ensure a default resource exists as well.
            folder = decoded / "res" / "mipmap"
            folder.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ICON, folder / "ic_launcher.png")

        rebuilt_apk = OUT / apk.name
        run(APKTOOL, "b", str(decoded), "-o", str(rebuilt_apk))
        rebuilt.append(rebuilt_apk)

    # Sign every split with the same temporary key so Android accepts the split set.
    keystore = WORK / "experiment.keystore"
    run("keytool", "-genkeypair", "-v", "-keystore", keystore, "-storepass", "android",
        "-keypass", "android", "-alias", "experiment", "-keyalg", "RSA", "-keysize", "2048",
        "-validity", "10000", "-dname", "CN=Viber Telegram Experiment")
    signed=[]
    for apk in rebuilt:
        aligned = OUT / (apk.stem + ".aligned.apk")
        signed_apk = OUT / apk.name
        run("zipalign", "-f", "4", apk, aligned)
        run("apksigner", "sign", "--ks", keystore, "--ks-pass", "pass:android",
            "--key-pass", "pass:android", "--out", signed_apk, aligned)
        aligned.unlink(missing_ok=True)
        signed.append(signed_apk)

    package = OUT / "Telegram_Viber_experiment.apks"
    with zipfile.ZipFile(package, "w", zipfile.ZIP_DEFLATED) as z:
        for apk in signed:
            z.write(apk, apk.name)
    print(f"Created {package}")
    print("NOTE: This is a best-effort resource/manifest rebrand. It does not turn Viber into Telegram.")

if __name__ == "__main__":
    main()
